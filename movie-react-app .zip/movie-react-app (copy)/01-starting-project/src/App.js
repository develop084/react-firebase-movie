import React, { useState, useEffect, useCallback } from "react";

import MoviesList from "./components/MoviesList";
import "./App.css";
import AddMovie from "./components/AddMovie";

function App() {
  const [movies, setMovies] = useState([]);
  const [isLoading, setisLoading] = useState(false);
  const [err, setErr] = useState(null);

  const fetchMovieHandler = useCallback(async () => {
    setisLoading(true);
    setErr(null);

    try {
      const response = await fetch(
        "https://react-app-movie-default-rtdb.firebaseio.com/movies.json/"
      );
      const data = await response.json();

      if (!response.ok) {
        throw new Error("Something went wrong!");
      }
      const loadedMovies =[];
      for(const key in data){
        loadedMovies.push({
          id: key,
          title: data[key].title,
          openingText: data[key].openingText,
          releaseDate: data[key].releaseDate
        })
      }
      setMovies(loadedMovies);
      setisLoading(false);
    } catch (err) {
      setErr(err.message);
    }
  }, []);

  useEffect(() => fetchMovieHandler(), []);

  function addMovieHandler(movie) {
    fetch("https://react-app-movie-default-rtdb.firebaseio.com/movies.json", {
      method: "POST",
      body: JSON.stringify(movie),
      headers: {
        "content-Type": "application/json",
      },
    })
      .then((response) => response.json())
      .then((data) => console.log(data));
  }

  return (
    <React.Fragment>
      <section>
        <AddMovie onAddMovie={addMovieHandler} />
        <button onClick={fetchMovieHandler}>Fetch Movies</button>
      </section>
      <section>
        {!isLoading && <MoviesList movies={movies} />}
        {isLoading && <p>Loading...</p>}
        {err && <p>{err}</p>}
      </section>
    </React.Fragment>
  );
}

export default App;
